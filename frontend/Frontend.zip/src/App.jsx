import React from 'react';
import './index.css';
import AppRoutes from './pages/AppRoutes';

const App = () => {
  return (
    <div className="App">
      <AppRoutes />
    </div>
  );
};

export default App;