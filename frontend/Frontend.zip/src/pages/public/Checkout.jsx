import { Elements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useCart } from '@/context/CartContext';
import CheckoutForm from '@/components/CheckoutForm';
// Update these imports:
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

export default function Checkout() {
  const { cartTotal } = useCart();

  return (
    <div className="max-w-4xl mx-auto p-4">
      <h1 className="text-3xl font-bold mb-6">Checkout</h1>
      
      <Card>
        <CardContent className="p-6">
          <div className="mb-6">
            <h2 className="text-xl font-semibold">Order Summary</h2>
            <p className="text-lg mt-2">Total: ${cartTotal.toFixed(2)}</p>
          </div>

          <Elements stripe={stripePromise}>
            <CheckoutForm total={cartTotal} />
          </Elements>
        </CardContent>
      </Card>
    </div>
  );
}