import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div>
      <h1>Welcome to the Homepage</h1>
      <p>Explore our products and services.</p>
      <nav>
        <ul>
          <li><Link to="/products">Products</Link></li>
          <li><Link to="/checkout">Checkout</Link></li>
          <li><Link to="/admin">Admin Dashboard</Link></li>
        </ul>
      </nav>
    </div>
  );
};

export default Home;