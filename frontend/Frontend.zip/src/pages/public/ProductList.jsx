export default function ProductList() {
    return (
      <div className="p-4">
        <h1 className="text-3xl font-bold mb-4">Our Products</h1>
        <p>Product list will appear here</p>
      </div>
    );
  }