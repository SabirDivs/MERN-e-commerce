export default function ProductManagement() {
  return <h1>Product Management</h1>;
}