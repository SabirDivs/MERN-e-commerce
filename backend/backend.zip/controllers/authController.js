exports.login = async (req, res) => {
    res.json({ message: 'Login endpoint' });
  };
  
  exports.register = async (req, res) => {
    res.json({ message: 'Register endpoint' });
  };